export const environment = {
  firebase: {
    projectId: 'angular-blog-fa29f',
    appId: '1:105993470880:web:1bf81027f5d39f61fd1ac5',
    storageBucket: 'angular-blog-fa29f.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyBskiJYa7Mtf5FBXt36ZR6Jffyex21kkcc',
    authDomain: 'angular-blog-fa29f.firebaseapp.com',
    messagingSenderId: '105993470880',
  },
  production: true
};
