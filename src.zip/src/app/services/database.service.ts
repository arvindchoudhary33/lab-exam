import { Injectable } from '@angular/core';
import {
  Firestore,
  query,
  where,
  getDocs,
  collection,
  addDoc,
} from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root',
})
export class DatabaseService {
  constructor(private store: Firestore) {}

  async fetchData() {
    let allData: Object[] = [];
    const querySnapshot = await getDocs(
      collection(this.store, 'list-of-students')
    );
    querySnapshot.forEach((doc) => {
      console.log(`${doc.id} => ${doc.data()}`);
      allData.push(Object(doc.data()));
    });
    return allData;
  }

  async fetchQueryData() {
    let allData: Object[] = [];
    const q = query(
      collection(this.store, 'list-of-students'),
      where('class', '==', 'msc')
    );
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      allData.push(Object(doc.data()));
      console.log('query data', doc.data());
    });
    return allData;
  }

  async putData(data: Object) {
    try {
      const docRef = await addDoc(
        collection(this.store, 'list-of-students'),
        data
      );
      console.log('Document written with ID: ', docRef.id);
    } catch (e) {
      console.error('Error adding document: ', e);
    }
  }
}
