import { Component, OnInit } from '@angular/core';
import { Firestore } from '@angular/fire/firestore';
import { FormControl, FormGroup } from '@angular/forms';
import { FirebaseSignInProvider } from '@firebase/util';
import { DatabaseService } from 'src/app/services/database.service';
export interface students {
  studentName: '';
  class: '';
  percentage: '';
  rollNumber: '';
}
@Component({
  selector: 'app-msc-students',
  templateUrl: './msc-students.component.html',
  styleUrls: ['./msc-students.component.scss'],
})
export class MscStudentsComponent implements OnInit {
  dataSource: students[] = [];

  displayedColumns: string[] = [
    'studentName',
    'rollNumber',
    'class',
    'percentage',
  ];

  constructor(private database: DatabaseService, private store: Firestore) { }

  ngOnInit(): void {
    this.fetchStudents();
  }

  studentsGroup = new FormGroup({
    studentName: new FormControl('', []),
    rollNumber: new FormControl('', []),
    class: new FormControl('', []),
    percentage: new FormControl('', []),
  });

  addStudents(data: any) {
    this.database.putData(data);
    console.log(data);
  }
  delete(id: string) {
    console.log(id)
    // this.store.collection('list-of-students').doc(id).delete();
  }


  fetchStudents() {
    this.database.fetchQueryData().then((value) => {
      for (let i = 0; i < value.length; i++) {
        this.dataSource.push(Object(value[i]));
      }
      console.log('wher is data', value);
    });
  }
  refresh() {
    this.fetchStudents();
    console.log('dataaaaaa', this.dataSource);
  }
}
